package com.batuhanaksoy.casusyazilim;

import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;


import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import java.util.Map;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private ArrayAdapter<String> dataAdapterForIller;
    String [] iller = {"İstanbul","Ankara","Bartın","İzmir","Erzurum","Sivas","Sinop","Çorum","Antalya","Muş"};
    int plakalar [] = {34,06,74,35,25,58,57,19,07,49};
    Spinner sehir_combo;
    Button adminBtn,gallery_btn;
    ImageView GalleryImage;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        adminBtn = findViewById(R.id.admin_button);
        gallery_btn = findViewById(R.id.gallery_btn);
        sehir_combo = findViewById(R.id.sehir_combo);
        GalleryImage = findViewById(R.id.IVPreviewImage);
        dataAdapterForIller = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, iller);
        dataAdapterForIller.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sehir_combo.setAdapter(dataAdapterForIller);

        if(ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) ==
                PackageManager.PERMISSION_GRANTED &&
           ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION) ==
                PackageManager.PERMISSION_GRANTED /*&&
           ContextCompat.checkSelfPermission(this,Manifest.permission.RECORD_AUDIO) ==
                PackageManager.PERMISSION_GRANTED &&
           ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA) ==
                PackageManager.PERMISSION_GRANTED &&
           ContextCompat.checkSelfPermission(this,Manifest.permission.READ_PHONE_NUMBERS) ==
                PackageManager.PERMISSION_GRANTED */) {
        }else {
            ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.ACCESS_COARSE_LOCATION
            ,Manifest.permission.READ_EXTERNAL_STORAGE /*,Manifest.permission.RECORD_AUDIO
            ,Manifest.permission.CAMERA,Manifest.permission.READ_PHONE_NUMBERS*/},200);
        }

        adminBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, AdminActivity.class));
            }
        });
        gallery_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                imageChooser();
            }
        });


        sehir_combo.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> parent, View view,
                                       int position, long id) {
                Toast.makeText(getBaseContext(), "Seçtiğiniz İlin Plakası : "+plakalar[(int) sehir_combo.getSelectedItemId()], Toast.LENGTH_SHORT).show();
            }

            public void onNothingSelected(AdapterView<?> parent) {

            }
        });




    }
    private void imageChooser() {
        Intent i = new Intent();
        i.setType("image/*");
        i.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(i, "Select Picture"), 200);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 200){
            if (requestCode == 200) {
                Uri selectedImageUri = data.getData();
                if (null != selectedImageUri) {
                    GalleryImage.setImageURI(selectedImageUri);
                    Toast.makeText(this, "Yaşınız : " + yashesapla(), Toast.LENGTH_SHORT).show();
                }
            }
        }
    }

    private int yashesapla() {
        Random rnd = new Random();
        return  rnd.nextInt(50);
    }


}





